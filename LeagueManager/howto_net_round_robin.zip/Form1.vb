Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtNumTeams As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents txtResults As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtNumTeams = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnGo = New System.Windows.Forms.Button
        Me.txtResults = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'txtNumTeams
        '
        Me.txtNumTeams.Location = New System.Drawing.Point(64, 8)
        Me.txtNumTeams.Name = "txtNumTeams"
        Me.txtNumTeams.Size = New System.Drawing.Size(48, 20)
        Me.txtNumTeams.TabIndex = 0
        Me.txtNumTeams.Text = "6"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "# Teams"
        '
        'btnGo
        '
        Me.btnGo.Location = New System.Drawing.Point(136, 8)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.Size = New System.Drawing.Size(40, 23)
        Me.btnGo.TabIndex = 2
        Me.btnGo.Text = "Go"
        '
        'txtResults
        '
        Me.txtResults.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtResults.Location = New System.Drawing.Point(0, 40)
        Me.txtResults.Multiline = True
        Me.txtResults.Name = "txtResults"
        Me.txtResults.Size = New System.Drawing.Size(291, 232)
        Me.txtResults.TabIndex = 3
        Me.txtResults.Text = ""
        '
        'Form1
        '
        Me.AcceptButton = Me.btnGo
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.txtResults)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtNumTeams)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Const BYE As Integer = -1

    ' Return an array where results(i, j) gives the opponent of
    ' team i in round j.
    Private Function GenerateRoundRobin(ByVal num_teams As Integer) As Integer(,)
        If num_teams Mod 2 = 0 Then
            GenerateRoundRobin = GenerateRoundRobinEven(num_teams)
        Else
            GenerateRoundRobin = GenerateRoundRobinOdd(num_teams)
        End If
    End Function

    ' Return an array where results(i, j) gives the opponent of
    ' team i in round j.
    ' Note: num_teams must be odd.
    Private Function GenerateRoundRobinOdd(ByVal num_teams As Integer) As Integer(,)
        Dim n2 As Integer
        Dim results(,) As Integer
        Dim teams() As Integer
        Dim i As Integer
        Dim round As Integer
        Dim team1 As Integer
        Dim team2 As Integer

        n2 = num_teams \ 2
        ReDim results(num_teams - 1, num_teams - 1)

        ' Initialize the list of teams.
        ReDim teams(num_teams - 1)
        For i = 0 To num_teams - 1
            teams(i) = i
        Next i

        ' Start the rounds.
        For round = 0 To num_teams - 1
            For i = 0 To n2 - 1
                team1 = teams(n2 - i)
                team2 = teams(n2 + i + 1)
                results(team1, round) = team2
                results(team2, round) = team1
            Next i

            ' Set the team with the bye.
            team1 = teams(0)
            results(team1, round) = BYE

            ' Rotate the array.
            RotateArray(teams)
        Next round

        Return results
    End Function

    ' Return an array where results(i, j) gives the opponent of
    ' team i in round j.
    ' Note: num_teams must be even.
    Private Function GenerateRoundRobinEven(ByVal num_teams As Integer) As Integer(,)
        Dim results(,) As Integer
        Dim results2(,) As Integer
        Dim round As Integer
        Dim team As Integer

        ' Generate the result for one fewer teams.
        results = GenerateRoundRobinOdd(num_teams - 1)

        ' Copy the results into a bigger array,
        ' replacing the byes with the extra team.
        ReDim results2(num_teams - 1, num_teams - 2)
        For team = 0 To num_teams - 2
            For round = 0 To num_teams - 2
                If results(team, round) = BYE Then
                    ' Change the bye to the new team.
                    results2(team, round) = num_teams - 1
                    results2(num_teams - 1, round) = team
                Else
                    results2(team, round) = results(team, round)
                End If
            Next round
        Next team

        Return results2
    End Function

    ' Rotate the entries one position.
    Private Sub RotateArray(ByVal teams() As Integer)
        Dim tmp As Integer
        Dim i As Integer

        tmp = teams(UBound(teams))
        For i = UBound(teams) To 1 Step -1
            teams(i) = teams(i - 1)
        Next i
        teams(0) = tmp
    End Sub

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Dim num_teams As Integer
        Dim num_rounds As Integer
        Dim results(,) As Integer
        Dim team As Integer
        Dim round As Integer
        Dim txt As String

        ' Get the schedule.
        num_teams = CInt(txtNumTeams.Text)
        results = GenerateRoundRobin(num_teams)

        ' Display the result.
        For round = results.GetLowerBound(1) To results.GetUpperBound(1)
            txt = txt & "Round " & round & ":" & vbCrLf
            For team = 0 To num_teams - 1
                If results(team, round) = BYE Then
                    txt &= "    " & team & " (bye)" & vbCrLf
                ElseIf team < results(team, round) Then
                    txt &= "    " & team & " v " & results(team, round) & vbCrLf
                End If
            Next team
        Next round

        txtResults.Text = txt
    End Sub
End Class
